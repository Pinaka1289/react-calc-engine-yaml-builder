"use client"

import { useEffect, useState } from "react"
import { Badge } from "./ui/badge"
import { Card, CardContent } from "./ui/card"
import { Button } from "./ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "./ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import ActionForm from "./action-form"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog"
import { Plus, MoreVertical, Layout, Grid, Workflow, Zap } from "lucide-react"

// Simple flow visualization without ReactFlow
export default function FlowVisualizer({ actions, setActions }) {
  const [actionCounts, setActionCounts] = useState({})
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [currentAction, setCurrentAction] = useState(null)
  const [editIndex, setEditIndex] = useState(null)
  const [insertPosition, setInsertPosition] = useState(null)
  const [layoutType, setLayoutType] = useState("hierarchical")

  useEffect(() => {
    const counts = {}
    actions.forEach((action) => {
      counts[action.action] = (counts[action.action] || 0) + 1
    })
    setActionCounts(counts)
  }, [actions])

  const handleEditAction = (action, index) => {
    if (!setActions) return
    setCurrentAction(action)
    setEditIndex(index)
    setIsEditDialogOpen(true)
  }

  const handleAddAction = (position = null) => {
    if (!setActions) return
    setCurrentAction(null)
    setEditIndex(null)
    setInsertPosition(position)
    setIsAddDialogOpen(true)
  }

  const handleDeleteAction = (index) => {
    if (!setActions) return
    const newActions = [...actions]
    newActions.splice(index, 1)
    setActions(newActions)
  }

  const handleSaveAction = (action) => {
    if (!setActions || editIndex === null) return
    const newActions = [...actions]
    newActions[editIndex] = action
    setActions(newActions)
    setIsEditDialogOpen(false)
    setCurrentAction(null)
    setEditIndex(null)
  }

  const handleSaveNewAction = (action) => {
    if (!setActions) return
    const newActions = [...actions]
    if (insertPosition !== null) {
      newActions.splice(insertPosition, 0, action)
    } else {
      newActions.push(action)
    }
    setActions(newActions)
    setIsAddDialogOpen(false)
    setCurrentAction(null)
    setInsertPosition(null)
  }

  const handleCancelEdit = () => {
    setIsEditDialogOpen(false)
    setCurrentAction(null)
    setEditIndex(null)
  }

  const handleCancelAdd = () => {
    setIsAddDialogOpen(false)
    setCurrentAction(null)
    setInsertPosition(null)
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-4 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-semibold">Flow Visualizer</h2>
          <div className="flex items-center space-x-2">
            <Layout className="h-4 w-4 text-gray-500" />
            <Select value={layoutType} onValueChange={setLayoutType}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Layout" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hierarchical">
                  <div className="flex items-center">
                    <Workflow className="mr-2 h-4 w-4" />
                    Hierarchical
                  </div>
                </SelectItem>
                <SelectItem value="grid">
                  <div className="flex items-center">
                    <Grid className="mr-2 h-4 w-4" />
                    Grid
                  </div>
                </SelectItem>
                <SelectItem value="timeline">
                  <div className="flex items-center">
                    <Zap className="mr-2 h-4 w-4" />
                    Timeline
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Badge variant="outline">Total: {actions.length}</Badge>
          {Object.entries(actionCounts).map(([action, count]) => (
            <Badge key={action} variant="secondary">
              {action}: {count}
            </Badge>
          ))}

          {setActions && (
            <>
              <Badge variant="outline" className="text-blue-600 border-blue-300">
                Click any action to edit
              </Badge>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Action
                    <MoreVertical className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleAddAction(0)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add at Beginning
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleAddAction()}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add at End
                  </DropdownMenuItem>
                  {actions.length > 0 && (
                    <>
                      <DropdownMenuSeparator />
                      <div className="px-2 py-1 text-xs font-medium text-gray-500">Insert After:</div>
                      {actions.map((action, index) => (
                        <DropdownMenuItem key={index} onClick={() => handleAddAction(index + 1)}>
                          <Plus className="mr-2 h-4 w-4" />
                          After "{action.name}"
                        </DropdownMenuItem>
                      ))}
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
        </div>
      </div>

      <Card className="flex-grow relative">
        <CardContent className="p-6">
          {actions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 py-12">
              <div className="text-center space-y-4 max-w-sm">
                <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
                  <Workflow className="w-8 h-8 text-gray-400" />
                </div>
                <div>
                  <p className="text-lg font-medium text-gray-900">No actions to visualize</p>
                  <p className="text-sm text-gray-500 mt-1">Add some actions to see the workflow visualization</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-sm text-gray-600 mb-4">
                {layoutType === "hierarchical" && "Top-down hierarchical flow"}
                {layoutType === "grid" && "Organized grid layout for easy scanning"}
                {layoutType === "timeline" && "Linear timeline showing sequential flow"}
              </div>

              {/* Simple visualization */}
              <div className="flex flex-wrap gap-4">
                {actions.map((action, index) => (
                  <div
                    key={index}
                    className="bg-white border-2 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer min-w-[200px]"
                    style={{ borderLeftColor: getActionColor(action.action), borderLeftWidth: "4px" }}
                    onClick={() => handleEditAction(action, index)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">{action.action}</h3>
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">#{index + 1}</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{action.name}</p>
                    <p className="text-xs text-blue-600">df: {action.dataframe}</p>
                    {index < actions.length - 1 && (
                      <div className="mt-2 text-center">
                        <div className="inline-block w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Action from Flow</DialogTitle>
          </DialogHeader>
          <ActionForm initialAction={currentAction} onSave={handleSaveAction} onCancel={handleCancelEdit} />
        </DialogContent>
      </Dialog>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Add New Action
              {insertPosition !== null && (
                <span className="text-sm font-normal text-gray-500 ml-2">(Position: {insertPosition + 1})</span>
              )}
            </DialogTitle>
          </DialogHeader>
          <ActionForm initialAction={null} onSave={handleSaveNewAction} onCancel={handleCancelAdd} />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function getActionColor(actionName) {
  const colorMap = {
    Extract: "#4CAF50",
    Execute: "#2196F3",
    Transform: "#FF9800",
    Load: "#9C27B0",
    Merge: "#F44336",
    Purge: "#795548",
    S3Replicate: "#607D8B",
    Include: "#009688",
  }
  return colorMap[actionName] || "#999999"
}
