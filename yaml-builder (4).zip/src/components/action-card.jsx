"use client"
import { Card, CardContent } from "./ui/card"
import { Button } from "./ui/button"
import { Edit, Trash2 } from "lucide-react"
import { getActionColor } from "../lib/action-definitions"
import ActionIcon from "./action-icon"

export default function ActionCard({ action, onEdit, onDelete, isDragging = false, dragHandle = false }) {
  const color = getActionColor(action.action)

  const getIconBackgroundColor = (color) => {
    const colorMap = {
      "#4CAF50": "#e8f5e8",
      "#2196F3": "#e3f2fd",
      "#FF9800": "#fff3e0",
      "#9C27B0": "#f3e5f5",
      "#F44336": "#ffebee",
      "#795548": "#efebe9",
      "#607D8B": "#eceff1",
      "#009688": "#e0f2f1",
    }
    return colorMap[color] || "#f5f5f5"
  }

  const iconBgColor = getIconBackgroundColor(color)

  return (
    <Card
      className={`border-l-4 bg-white shadow-sm hover:shadow-md transition-all duration-200 ${
        isDragging ? "shadow-2xl border-blue-300 bg-blue-50" : "hover:border-l-8"
      }`}
      style={{ borderLeftColor: color }}
    >
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div
            className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${
              isDragging ? "scale-110" : ""
            }`}
            style={{ backgroundColor: iconBgColor }}
          >
            <ActionIcon actionType={action.action} className="w-6 h-6" style={{ color: color }} />
          </div>

          <div className="flex-grow min-w-0">
            <h3
              className={`font-semibold text-gray-900 text-lg leading-tight transition-all duration-200 ${
                isDragging ? "text-blue-900" : ""
              }`}
            >
              {action.name}
            </h3>
            <p
              className={`text-gray-500 text-sm mt-1 transition-all duration-200 ${isDragging ? "text-blue-700" : ""}`}
            >
              Action: {action.action.toLowerCase()}
            </p>

            <div className="mt-2 space-y-1">
              <div className={`text-xs transition-all duration-200 ${isDragging ? "text-blue-600" : "text-gray-600"}`}>
                <span className="font-medium">Dataframe:</span> {action.dataframe}
              </div>
              {Object.entries(action).map(([key, value]) => {
                if (key === "action" || key === "name" || key === "dataframe") return null

                const displayValue =
                  typeof value === "string" ? value : Array.isArray(value) ? value.join(", ") : JSON.stringify(value)

                return (
                  <div
                    key={key}
                    className={`text-xs transition-all duration-200 ${isDragging ? "text-blue-600" : "text-gray-600"}`}
                  >
                    <span className="font-medium">{key}:</span>{" "}
                    <span className="truncate inline-block max-w-[200px]" title={displayValue}>
                      {displayValue.length > 30 ? displayValue.substring(0, 30) + "..." : displayValue}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>

          <div className={`flex-shrink-0 flex space-x-1 transition-all duration-200 ${isDragging ? "opacity-50" : ""}`}>
            <Button
              variant="ghost"
              size="sm"
              onClick={onEdit}
              className="h-8 w-8 p-0 hover:bg-blue-100"
              disabled={isDragging}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onDelete}
              className="h-8 w-8 p-0 hover:bg-red-100"
              disabled={isDragging}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
