"use client"

import { useState } from "react"
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"
import { Plus, GripVertical, ArrowDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import ActionCard from "@/components/action-card"
import ActionForm from "@/components/action-form"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

/**
 * @param {Object} props
 * @param {import('../lib/types.js').ActionType[]} props.actions
 * @param {function(import('../lib/types.js').ActionType[]): void} props.setActions
 */
export default function ActionBuilder({ actions, setActions }) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentAction, setCurrentAction] = useState(null)
  const [editIndex, setEditIndex] = useState(null)
  const [draggedIndex, setDraggedIndex] = useState(null)

  const handleAddAction = () => {
    setCurrentAction(null)
    setEditIndex(null)
    setIsDialogOpen(true)
  }

  /**
   * @param {import('../lib/types.js').ActionType} action
   * @param {number} index
   */
  const handleEditAction = (action, index) => {
    setCurrentAction(action)
    setEditIndex(index)
    setIsDialogOpen(true)
  }

  /**
   * @param {number} index
   */
  const handleDeleteAction = (index) => {
    const newActions = [...actions]
    newActions.splice(index, 1)
    setActions(newActions)
  }

  /**
   * @param {import('../lib/types.js').ActionType} action
   */
  const handleSaveAction = (action) => {
    const newActions = [...actions]

    if (editIndex !== null) {
      newActions[editIndex] = action
    } else {
      newActions.push(action)
    }

    setActions(newActions)
    setIsDialogOpen(false)
  }

  /**
   * @param {any} start
   */
  const handleDragStart = (start) => {
    setDraggedIndex(start.source.index)
  }

  /**
   * @param {any} result
   */
  const handleDragEnd = (result) => {
    setDraggedIndex(null)

    // If dropped outside a droppable area
    if (!result.destination) return

    const sourceIndex = result.source.index
    const destinationIndex = result.destination.index

    // If dropped in the same position, do nothing
    if (sourceIndex === destinationIndex) return

    const newActions = Array.from(actions)

    // Remove the item from the source position
    const [movedItem] = newActions.splice(sourceIndex, 1)

    // Insert the item at the destination position
    newActions.splice(destinationIndex, 0, movedItem)

    setActions(newActions)
  }

  return (
    <div className="h-full flex flex-col bg-gray-50">
      <div className="flex justify-between items-center mb-6 px-6 pt-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-semibold text-gray-900">Actions</h2>
          {draggedIndex !== null && (
            <div className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium animate-pulse">
              <GripVertical className="inline h-4 w-4 mr-1" />
              Dragging: {actions[draggedIndex]?.name}
            </div>
          )}
        </div>
        <Button onClick={handleAddAction} className="shadow-sm">
          <Plus className="mr-2 h-4 w-4" /> Add Action
        </Button>
      </div>

      <DragDropContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
        <Droppable droppableId="actions" type="ACTION">
          {(provided, snapshot) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className={`flex-grow overflow-y-auto px-6 pb-6 transition-all duration-300 ${
                snapshot.isDraggingOver ? "bg-blue-50/50" : ""
              }`}
            >
              {actions.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500 py-12">
                  <div className="text-center space-y-4 max-w-sm">
                    <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
                      <Plus className="w-8 h-8 text-gray-400" />
                    </div>
                    <div>
                      <p className="text-lg font-medium text-gray-900">No actions yet</p>
                      <p className="text-sm text-gray-500 mt-1">
                        Click "Add Action" to create your first workflow step
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  {actions.map((action, index) => (
                    <div key={`action-${index}`} className="relative">
                      {/* Drop zone above each item (except first when dragging that item) */}
                      {draggedIndex !== null && draggedIndex !== index && (
                        <div
                          className={`h-2 mb-2 transition-all duration-200 ${
                            snapshot.isDraggingOver
                              ? "h-12 bg-blue-100 border-2 border-dashed border-blue-300 rounded-lg flex items-center justify-center"
                              : "bg-transparent"
                          }`}
                        >
                          {snapshot.isDraggingOver && (
                            <div className="flex items-center text-blue-600 font-medium text-sm">
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Drop here to insert before "{action.name}"
                            </div>
                          )}
                        </div>
                      )}

                      <Draggable draggableId={`action-${index}`} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={`transition-all duration-200 ${
                              snapshot.isDragging
                                ? "z-50 rotate-1 scale-105 shadow-2xl"
                                : draggedIndex !== null && draggedIndex !== index
                                  ? "opacity-60 scale-98 blur-[0.5px]"
                                  : "hover:scale-[1.01] hover:shadow-md"
                            }`}
                          >
                            <div className="relative">
                              {/* Drag handle overlay */}
                              <div
                                {...provided.dragHandleProps}
                                className={`absolute left-2 top-1/2 transform -translate-y-1/2 z-10 p-2 rounded cursor-grab active:cursor-grabbing transition-all duration-200 ${
                                  snapshot.isDragging
                                    ? "bg-blue-500 text-white shadow-lg scale-110"
                                    : "bg-white/90 text-gray-400 hover:bg-blue-100 hover:text-blue-600 shadow-sm hover:scale-110"
                                }`}
                                title="Drag to reorder"
                              >
                                <GripVertical className="h-4 w-4" />
                              </div>

                              {/* Action Card with left padding for drag handle */}
                              <div className="pl-12">
                                <ActionCard
                                  action={action}
                                  onEdit={() => handleEditAction(action, index)}
                                  onDelete={() => handleDeleteAction(index)}
                                  isDragging={snapshot.isDragging}
                                  dragHandle={false}
                                />
                              </div>

                              {/* Position indicator */}
                              {!snapshot.isDragging && (
                                <div className="absolute right-2 top-2 bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded-full">
                                  #{index + 1}
                                </div>
                              )}

                              {/* Dragging indicator */}
                              {snapshot.isDragging && (
                                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full shadow-lg">
                                  Moving to new position...
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </Draggable>

                      {/* Drop zone after last item */}
                      {index === actions.length - 1 && draggedIndex !== null && draggedIndex !== index && (
                        <div
                          className={`h-2 mt-2 transition-all duration-200 ${
                            snapshot.isDraggingOver
                              ? "h-12 bg-blue-100 border-2 border-dashed border-blue-300 rounded-lg flex items-center justify-center"
                              : "bg-transparent"
                          }`}
                        >
                          {snapshot.isDraggingOver && (
                            <div className="flex items-center text-blue-600 font-medium text-sm">
                              <ArrowDown className="h-4 w-4 mr-2" />
                              Drop here to add at the end
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}

                  {provided.placeholder}

                  {/* Global drag instruction */}
                  {draggedIndex !== null && (
                    <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <GripVertical className="h-5 w-5 text-blue-600" />
                        <p className="text-blue-800 font-medium">Dragging: "{actions[draggedIndex]?.name}"</p>
                      </div>
                      <div className="text-center">
                        <p className="text-blue-700 text-sm">
                          Drop in any blue zone to reorder • Other cards are dimmed for clarity
                        </p>
                        <div className="flex items-center justify-center mt-2 space-x-4 text-xs text-blue-600">
                          <span>
                            • Drag handle: <GripVertical className="inline h-3 w-3" />
                          </span>
                          <span>• Drop zones: Blue dashed areas</span>
                          <span>• Cancel: Drop outside list</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editIndex !== null ? "Edit Action" : "Add New Action"}</DialogTitle>
          </DialogHeader>
          <ActionForm initialAction={currentAction} onSave={handleSaveAction} onCancel={() => setIsDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  )
}
