import * as LucideIcons from "lucide-react"

interface LucideIconProps {
  name: string
  className?: string
}

export function LucideIcon({ name, className }: LucideIconProps) {
  const Icon = (LucideIcons as any)[name] || LucideIcons.HelpCircle

  return <Icon className={className} />
}
