export interface StageType {
  id: string
  name: string
  color: string
  icon: string
}

export interface Stage {
  id: string
  type: string
  name: string
  color: string
  icon: string
  properties: Record<string, string>
}
