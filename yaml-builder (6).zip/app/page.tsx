"use client"

import { useState } from "react"
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core"
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { restrictToVerticalAxis } from "@dnd-kit/modifiers"
import { SortableStage } from "@/components/sortable-stage"
import { StageEditor } from "@/components/stage-editor"
import type { StageType, Stage } from "@/lib/types"
import { generateYaml } from "@/lib/yaml-generator"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Download, Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const stageTypes: StageType[] = [
  { id: "build", name: "Build", color: "bg-blue-500", icon: "package" },
  { id: "test", name: "Test", color: "bg-green-500", icon: "check-circle" },
  { id: "deploy", name: "Deploy", color: "bg-purple-500", icon: "rocket" },
  { id: "notify", name: "Notify", color: "bg-yellow-500", icon: "bell" },
  { id: "approval", name: "Approval", color: "bg-red-500", icon: "user-check" },
]

export default function YamlBuilder() {
  const [stages, setStages] = useState<Stage[]>([])
  const [activeStage, setActiveStage] = useState<Stage | null>(null)
  const [yamlOutput, setYamlOutput] = useState("")
  const { toast } = useToast()

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  const handleDragEnd = (event: any) => {
    const { active, over } = event

    if (active.id !== over.id) {
      setStages((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  const addStage = (type: StageType) => {
    const newStage: Stage = {
      id: `stage-${Date.now()}`,
      type: type.id,
      name: `${type.name} ${stages.filter((s) => s.type === type.id).length + 1}`,
      color: type.color,
      icon: type.icon,
      properties: {},
    }
    setStages([...stages, newStage])
  }

  const updateStage = (updatedStage: Stage) => {
    setStages(stages.map((stage) => (stage.id === updatedStage.id ? updatedStage : stage)))
    setActiveStage(null)
  }

  const removeStage = (id: string) => {
    setStages(stages.filter((stage) => stage.id !== id))
    if (activeStage?.id === id) {
      setActiveStage(null)
    }
  }

  const generateOutput = () => {
    const yaml = generateYaml(stages)
    setYamlOutput(yaml)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(yamlOutput)
    toast({
      title: "Copied to clipboard",
      description: "YAML content has been copied to your clipboard",
    })
  }

  const downloadYaml = () => {
    const blob = new Blob([yamlOutput], { type: "text/yaml" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "pipeline.yaml"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">YAML Pipeline Builder</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-muted p-4 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Stage Types</h2>
          <div className="space-y-2">
            {stageTypes.map((type) => (
              <Button key={type.id} variant="outline" className="w-full justify-start" onClick={() => addStage(type)}>
                <div className={`w-4 h-4 rounded-full ${type.color} mr-2`}></div>
                <Plus className="mr-2 h-4 w-4" />
                {type.name}
              </Button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="editor">
            <TabsList className="mb-4">
              <TabsTrigger value="editor">Pipeline Editor</TabsTrigger>
              <TabsTrigger value="yaml" onClick={generateOutput}>
                YAML Output
              </TabsTrigger>
            </TabsList>

            <TabsContent value="editor" className="space-y-4">
              <div className="bg-muted p-4 rounded-lg min-h-[400px]">
                {stages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                    <p>Drag and drop stages to build your pipeline</p>
                    <p className="text-sm">Add stages from the left panel</p>
                  </div>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                    modifiers={[restrictToVerticalAxis]}
                  >
                    <SortableContext items={stages.map((s) => s.id)} strategy={verticalListSortingStrategy}>
                      <div className="space-y-2">
                        {stages.map((stage) => (
                          <SortableStage
                            key={stage.id}
                            stage={stage}
                            onEdit={() => setActiveStage(stage)}
                            onRemove={() => removeStage(stage.id)}
                          />
                        ))}
                      </div>
                    </SortableContext>
                  </DndContext>
                )}
              </div>
            </TabsContent>

            <TabsContent value="yaml">
              <div className="bg-muted p-4 rounded-lg">
                <div className="flex justify-end space-x-2 mb-2">
                  <Button variant="outline" size="sm" onClick={copyToClipboard}>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadYaml}>
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
                <pre className="bg-background p-4 rounded-md overflow-x-auto">
                  <code>{yamlOutput || "# Generate YAML by adding stages to your pipeline"}</code>
                </pre>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {activeStage && <StageEditor stage={activeStage} onSave={updateStage} onCancel={() => setActiveStage(null)} />}
    </div>
  )
}
