"use client"

import { useState, useEffect } from "react"
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from "@dnd-kit/core"
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { restrictToVerticalAxis } from "@dnd-kit/modifiers"
import { SortableAction } from "@/components/sortable-action"
import { ActionEditor } from "@/components/action-editor"
import { FlowVisualizer } from "@/components/flow-visualizer"
import { YamlEditor } from "@/components/yaml-editor"
import { FileUploader } from "@/components/file-uploader"
import { generateYaml, parseYaml, formatYaml } from "@/lib/yaml-generator"
import { actionTypes, getActionSchema } from "@/lib/action-schemas"
import { detectDependencies } from "@/lib/dependency-detector"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Download, Copy, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function YamlBuilder() {
  // Initialize actions as an empty array to prevent "map is not a function" error
  const [actions, setActions] = useState([])
  const [activeAction, setActiveAction] = useState(null)
  const [yamlOutput, setYamlOutput] = useState("")
  const [connections, setConnections] = useState([])
  const [yamlErrors, setYamlErrors] = useState([])
  const [showUploader, setShowUploader] = useState(false)
  const { toast } = useToast()

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  const handleDragEnd = (event) => {
    const { active, over } = event

    if (active.id !== over.id) {
      setActions((items) => {
        if (!Array.isArray(items)) {
          console.error("Expected items to be an array but got:", items)
          return []
        }
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over.id)
        const newActions = arrayMove(items, oldIndex, newIndex)
        updateConnections(newActions)
        return newActions
      })
    }
  }

  const addAction = (type) => {
    const schema = getActionSchema(type.id)
    const newAction = {
      id: `action-${Date.now()}`,
      action: type.id,
      name: `${type.name} ${actions.filter((a) => a.action === type.id).length + 1}`,
      color: type.color,
      icon: type.icon,
      shape: type.shape,
      properties: {},
      dependencies: [],
    }

    // Set default mandatory properties
    schema.mandatory.forEach((prop) => {
      if (prop !== "action" && prop !== "name") {
        newAction.properties[prop] = ""
      }
    })

    const newActions = [...actions, newAction]
    setActions(newActions)
    updateConnections(newActions)
  }

  const updateAction = (updatedAction) => {
    if (!Array.isArray(actions)) {
      console.error("Expected actions to be an array but got:", actions)
      setActions([updatedAction])
      return
    }

    const newActions = actions.map((action) => (action.id === updatedAction.id ? updatedAction : action))
    setActions(newActions)
    updateConnections(newActions)
    setActiveAction(null)
  }

  const removeAction = (id) => {
    if (!Array.isArray(actions)) {
      console.error("Expected actions to be an array but got:", actions)
      setActions([])
      return
    }

    const updatedActions = actions.filter((action) => action.id !== id)
    setActions(updatedActions)
    updateConnections(updatedActions)

    if (activeAction?.id === id) {
      setActiveAction(null)
    }
  }

  const updateConnections = (currentActions) => {
    if (!Array.isArray(currentActions)) {
      console.error("Expected currentActions to be an array but got:", currentActions)
      setConnections([])
      return
    }

    try {
      const newConnections = detectDependencies(currentActions)
      setConnections(newConnections)

      // Update action dependencies based on detected connections
      const actionsWithDeps = currentActions.map((action) => ({
        ...action,
        dependencies: newConnections.filter((conn) => conn.to === action.id).map((conn) => conn.from),
      }))

      if (JSON.stringify(actionsWithDeps) !== JSON.stringify(currentActions)) {
        setActions(actionsWithDeps)
      }
    } catch (error) {
      console.error("Error updating connections:", error)
      setConnections([])
    }
  }

  const generateOutput = () => {
    try {
      const yaml = generateYaml(actions)
      setYamlOutput(yaml)
    } catch (error) {
      console.error("Error generating YAML:", error)
      setYamlOutput("# Error generating YAML")
    }
  }

  const handleYamlChange = (newYaml) => {
    setYamlOutput(newYaml)
    try {
      const parsedActions = parseYaml(newYaml)
      if (Array.isArray(parsedActions)) {
        setActions(parsedActions)
        updateConnections(parsedActions)
        setYamlErrors([])
      } else {
        console.error("Expected parsedActions to be an array but got:", parsedActions)
        setYamlErrors([{ message: "Failed to parse YAML: Invalid format", line: 1 }])
      }
    } catch (error) {
      console.error("Error parsing YAML:", error)
      setYamlErrors([{ message: error.message, line: error.line || 1 }])
    }
  }

  const handleFileUpload = (content) => {
    try {
      // Try to format the YAML first to fix minor issues
      const formattedYaml = formatYaml(content)

      const parsedActions = parseYaml(formattedYaml)
      if (Array.isArray(parsedActions)) {
        setActions(parsedActions)
        updateConnections(parsedActions)
        setYamlOutput(formattedYaml)
        setYamlErrors([])
        setShowUploader(false)
        toast({
          title: "File uploaded successfully",
          description: "YAML file has been parsed and loaded",
        })
      } else {
        throw new Error("Invalid YAML format")
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      setYamlErrors([{ message: error.message, line: error.line || 1 }])
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(yamlOutput)
    toast({
      title: "Copied to clipboard",
      description: "YAML content has been copied to your clipboard",
    })
  }

  const downloadYaml = () => {
    const blob = new Blob([yamlOutput], { type: "text/yaml" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "pipeline.yaml"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  useEffect(() => {
    if (Array.isArray(actions)) {
      updateConnections(actions)
    }
  }, [])

  useEffect(() => {
    if (Array.isArray(actions)) {
      generateOutput()
    }
  }, [actions])

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">YAML Pipeline Builder</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowUploader(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Upload YAML
          </Button>
          <Button variant="outline" onClick={copyToClipboard}>
            <Copy className="h-4 w-4 mr-2" />
            Copy
          </Button>
          <Button variant="outline" onClick={downloadYaml}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 bg-muted p-4 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Action Types</h2>
          <div className="space-y-2">
            {actionTypes.map((type) => (
              <Button key={type.id} variant="outline" className="w-full justify-start" onClick={() => addAction(type)}>
                <div className={`w-4 h-4 ${type.shape} ${type.color} mr-2`}></div>
                <Plus className="mr-2 h-4 w-4" />
                {type.name}
              </Button>
            ))}
          </div>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="builder">
            <TabsList className="mb-4">
              <TabsTrigger value="builder">Pipeline Builder</TabsTrigger>
              <TabsTrigger value="visualizer">Flow Visualizer</TabsTrigger>
              <TabsTrigger value="yaml">YAML Editor</TabsTrigger>
            </TabsList>

            <TabsContent value="builder" className="space-y-4">
              <div className="bg-muted p-4 rounded-lg min-h-[400px]">
                {!Array.isArray(actions) || actions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                    <p>Drag and drop actions to build your pipeline</p>
                    <p className="text-sm">Add actions from the left panel</p>
                  </div>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                    modifiers={[restrictToVerticalAxis]}
                  >
                    <SortableContext items={actions.map((a) => a.id)} strategy={verticalListSortingStrategy}>
                      <div className="space-y-2">
                        {actions.map((action) => (
                          <SortableAction
                            key={action.id}
                            action={action}
                            onEdit={() => setActiveAction(action)}
                            onRemove={() => removeAction(action.id)}
                          />
                        ))}
                      </div>
                    </SortableContext>
                  </DndContext>
                )}
              </div>
            </TabsContent>

            <TabsContent value="visualizer">
              <div className="bg-muted p-4 rounded-lg min-h-[500px]">
                <FlowVisualizer
                  actions={Array.isArray(actions) ? actions : []}
                  connections={connections}
                  onActionEdit={(action) => setActiveAction(action)}
                  onActionRemove={removeAction}
                  onActionAdd={addAction}
                />
              </div>
            </TabsContent>

            <TabsContent value="yaml">
              <YamlEditor value={yamlOutput} onChange={handleYamlChange} errors={yamlErrors} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {activeAction && (
        <ActionEditor
          action={activeAction}
          allActions={Array.isArray(actions) ? actions : []}
          onSave={updateAction}
          onCancel={() => setActiveAction(null)}
        />
      )}

      {showUploader && <FileUploader onUpload={handleFileUpload} onCancel={() => setShowUploader(false)} />}
    </div>
  )
}
