"use client"

import type React from "react"

import { useState } from "react"
import type { Stage } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LucideIcon } from "@/lib/icons"
import { Trash2 } from "lucide-react"

interface StageEditorProps {
  stage: Stage
  onSave: (stage: Stage) => void
  onCancel: () => void
}

export function StageEditor({ stage, onSave, onCancel }: StageEditorProps) {
  const [editedStage, setEditedStage] = useState<Stage>({ ...stage })
  const [newPropertyKey, setNewPropertyKey] = useState("")
  const [newPropertyValue, setNewPropertyValue] = useState("")

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditedStage({ ...editedStage, name: e.target.value })
  }

  const addProperty = () => {
    if (newPropertyKey.trim() === "") return

    setEditedStage({
      ...editedStage,
      properties: {
        ...editedStage.properties,
        [newPropertyKey]: newPropertyValue,
      },
    })

    setNewPropertyKey("")
    setNewPropertyValue("")
  }

  const removeProperty = (key: string) => {
    const updatedProperties = { ...editedStage.properties }
    delete updatedProperties[key]

    setEditedStage({
      ...editedStage,
      properties: updatedProperties,
    })
  }

  const updatePropertyValue = (key: string, value: string) => {
    setEditedStage({
      ...editedStage,
      properties: {
        ...editedStage.properties,
        [key]: value,
      },
    })
  }

  return (
    <Dialog open={true} onOpenChange={() => onCancel()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Stage</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic">
          <TabsList className="mb-4">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="properties">Properties</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <div className="flex items-center gap-4 mb-4">
              <div className={`p-3 rounded-md ${editedStage.color}`}>
                <LucideIcon name={editedStage.icon} className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-medium">
                  {editedStage.type.charAt(0).toUpperCase() + editedStage.type.slice(1)} Stage
                </p>
                <p className="text-sm text-muted-foreground">Configure the basic settings</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Stage Name</Label>
                <Input id="name" value={editedStage.name} onChange={handleNameChange} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="properties" className="space-y-4">
            <div className="space-y-4">
              {Object.keys(editedStage.properties).length > 0 ? (
                <div className="space-y-2">
                  {Object.entries(editedStage.properties).map(([key, value]) => (
                    <div key={key} className="flex items-center gap-2">
                      <Input value={key} disabled className="flex-1" />
                      <Input
                        value={value}
                        onChange={(e) => updatePropertyValue(key, e.target.value)}
                        className="flex-1"
                      />
                      <Button variant="ghost" size="icon" onClick={() => removeProperty(key)}>
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No properties configured yet</p>
              )}

              <div className="pt-4 border-t">
                <p className="text-sm font-medium mb-2">Add New Property</p>
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Key"
                    value={newPropertyKey}
                    onChange={(e) => setNewPropertyKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={newPropertyValue}
                    onChange={(e) => setNewPropertyValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={addProperty}>Add</Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={() => onSave(editedStage)}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
