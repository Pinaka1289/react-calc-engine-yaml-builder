"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { formatYaml } from "@/lib/yaml-generator"

export function YamlEditor({ value, onChange, errors }) {
  const [localValue, setLocalValue] = useState(value)
  const [highlightedLine, setHighlightedLine] = useState(null)

  useEffect(() => {
    setLocalValue(value)
  }, [value])

  useEffect(() => {
    if (errors && errors.length > 0) {
      setHighlightedLine(errors[0].line)
    } else {
      setHighlightedLine(null)
    }
  }, [errors])

  const handleChange = (e) => {
    const newValue = e.target.value
    setLocalValue(newValue)
    onChange(newValue)
  }

  const handleFormat = () => {
    try {
      const formattedYaml = formatYaml(localValue)
      setLocalValue(formattedYaml)
      onChange(formattedYaml)
    } catch (error) {
      console.error("Error formatting YAML:", error)
    }
  }

  const lineNumbers = localValue.split("\n").map((_, index) => index + 1)

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="space-y-2">
          {errors.map((error, index) => (
            <Alert key={index} variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Line {error.line}: {error.message}
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      <div className="flex justify-end mb-2">
        <Button variant="outline" size="sm" onClick={handleFormat}>
          Format YAML
        </Button>
      </div>

      <div className="bg-muted p-4 rounded-lg">
        <div className="flex">
          <div className="bg-background p-2 rounded-l-md border-r">
            <div className="text-xs text-muted-foreground space-y-1 font-mono">
              {lineNumbers.map((num) => (
                <div
                  key={num}
                  className={`h-5 leading-5 px-2 ${highlightedLine === num ? "bg-red-100 text-red-800 font-bold" : ""}`}
                >
                  {num}
                </div>
              ))}
            </div>
          </div>
          <textarea
            value={localValue}
            onChange={handleChange}
            className="flex-1 p-2 bg-background rounded-r-md border-0 resize-none font-mono text-sm min-h-[400px] focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="# Your YAML content will appear here"
            spellCheck={false}
          />
        </div>
      </div>

      <div className="text-sm text-muted-foreground">
        <p>
          <strong>Tip:</strong> Maintain consistent indentation. Use 2 spaces for each level. Actions start with "-
          action:" and all properties should be aligned.
        </p>
      </div>
    </div>
  )
}
