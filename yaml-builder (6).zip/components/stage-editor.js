"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { LucideIcon } from "@/lib/icons"
import { Trash2 } from "lucide-react"

export function StageEditor({ stage, allStages, onSave, onCancel }) {
  const [editedStage, setEditedStage] = useState({ ...stage })
  const [newPropertyKey, setNewPropertyKey] = useState("")
  const [newPropertyValue, setNewPropertyValue] = useState("")

  const handleNameChange = (e) => {
    setEditedStage({ ...editedStage, name: e.target.value })
  }

  const addProperty = () => {
    if (newPropertyKey.trim() === "") return

    setEditedStage({
      ...editedStage,
      properties: {
        ...editedStage.properties,
        [newPropertyKey]: newPropertyValue,
      },
    })

    setNewPropertyKey("")
    setNewPropertyValue("")
  }

  const removeProperty = (key) => {
    const updatedProperties = { ...editedStage.properties }
    delete updatedProperties[key]

    setEditedStage({
      ...editedStage,
      properties: updatedProperties,
    })
  }

  const updatePropertyValue = (key, value) => {
    setEditedStage({
      ...editedStage,
      properties: {
        ...editedStage.properties,
        [key]: value,
      },
    })
  }

  const toggleDependency = (stageId) => {
    const currentDependencies = editedStage.dependencies || []

    if (currentDependencies.includes(stageId)) {
      setEditedStage({
        ...editedStage,
        dependencies: currentDependencies.filter((id) => id !== stageId),
      })
    } else {
      setEditedStage({
        ...editedStage,
        dependencies: [...currentDependencies, stageId],
      })
    }
  }

  // Filter out the current stage from potential dependencies
  const potentialDependencies = allStages.filter((s) => s.id !== stage.id)

  return (
    <Dialog open={true} onOpenChange={() => onCancel()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Stage</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic">
          <TabsList className="mb-4">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
            <TabsTrigger value="properties">Properties</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <div className="flex items-center gap-4 mb-4">
              <div className={`p-3 rounded-md ${editedStage.color}`}>
                <LucideIcon name={editedStage.icon} className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-medium">
                  {editedStage.type.charAt(0).toUpperCase() + editedStage.type.slice(1)} Stage
                </p>
                <p className="text-sm text-muted-foreground">Configure the basic settings</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Stage Name</Label>
                <Input id="name" value={editedStage.name} onChange={handleNameChange} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="dependencies" className="space-y-4">
            <div className="space-y-2">
              <Label>Stage Dependencies</Label>
              <p className="text-sm text-muted-foreground mb-4">
                Select stages that must complete before this stage can run
              </p>

              {potentialDependencies.length > 0 ? (
                <div className="space-y-2">
                  {potentialDependencies.map((depStage) => (
                    <div key={depStage.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`dep-${depStage.id}`}
                        checked={(editedStage.dependencies || []).includes(depStage.id)}
                        onCheckedChange={() => toggleDependency(depStage.id)}
                      />
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full ${depStage.color} mr-2`}></div>
                        <Label htmlFor={`dep-${depStage.id}`} className="cursor-pointer">
                          {depStage.name}
                        </Label>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm italic">No other stages available to depend on</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="properties" className="space-y-4">
            <div className="space-y-4">
              {Object.keys(editedStage.properties || {}).length > 0 ? (
                <div className="space-y-2">
                  {Object.entries(editedStage.properties).map(([key, value]) => (
                    <div key={key} className="flex items-center gap-2">
                      <Input value={key} disabled className="flex-1" />
                      <Input
                        value={value}
                        onChange={(e) => updatePropertyValue(key, e.target.value)}
                        className="flex-1"
                      />
                      <Button variant="ghost" size="icon" onClick={() => removeProperty(key)}>
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No properties configured yet</p>
              )}

              <div className="pt-4 border-t">
                <p className="text-sm font-medium mb-2">Add New Property</p>
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Key"
                    value={newPropertyKey}
                    onChange={(e) => setNewPropertyKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={newPropertyValue}
                    onChange={(e) => setNewPropertyValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={addProperty}>Add</Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={() => onSave(editedStage)}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
