"use client"

import { useEffect, useRef, useState } from "react"
import { LucideIcon } from "@/lib/icons"
import { Button } from "@/components/ui/button"
import { Pencil, Trash2, Plus } from "lucide-react"
import { actionTypes } from "@/lib/action-schemas"

export function PipelineVisualizer({ actions, connections, onActionEdit, onActionRemove, onActionAdd }) {
  const canvasRef = useRef(null)
  const containerRef = useRef(null)
  const [draggedAction, setDraggedAction] = useState(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!canvasRef.current || actions.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas dimensions
    const container = canvas.parentElement
    canvas.width = container.offsetWidth
    canvas.height = container.offsetHeight

    // Draw connections
    ctx.strokeStyle = "#64748b"
    ctx.lineWidth = 3

    connections.forEach((connection) => {
      const fromElement = document.getElementById(`visual-action-${connection.from}`)
      const toElement = document.getElementById(`visual-action-${connection.to}`)

      if (fromElement && toElement) {
        const fromRect = fromElement.getBoundingClientRect()
        const toRect = toElement.getBoundingClientRect()
        const canvasRect = canvas.getBoundingClientRect()

        const fromX = fromRect.left + fromRect.width / 2 - canvasRect.left
        const fromY = fromRect.top + fromRect.height / 2 - canvasRect.top
        const toX = toRect.left + toRect.width / 2 - canvasRect.left
        const toY = toRect.top + toRect.height / 2 - canvasRect.top

        // Draw curved arrow
        ctx.beginPath()
        ctx.moveTo(fromX, fromY)

        const controlX = (fromX + toX) / 2
        const controlY = (fromY + toY) / 2 - 50

        ctx.quadraticCurveTo(controlX, controlY, toX, toY)
        ctx.stroke()

        // Draw arrow head
        const angle = Math.atan2(toY - controlY, toX - controlX)
        const arrowSize = 12

        ctx.beginPath()
        ctx.moveTo(toX, toY)
        ctx.lineTo(toX - arrowSize * Math.cos(angle - Math.PI / 6), toY - arrowSize * Math.sin(angle - Math.PI / 6))
        ctx.lineTo(toX - arrowSize * Math.cos(angle + Math.PI / 6), toY - arrowSize * Math.sin(angle + Math.PI / 6))
        ctx.closePath()
        ctx.fillStyle = "#64748b"
        ctx.fill()
      }
    })
  }, [actions, connections])

  const handleDragStart = (e, action) => {
    setDraggedAction(action)
    const rect = e.currentTarget.getBoundingClientRect()
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    })
  }

  const handleDragOver = (e) => {
    e.preventDefault()
  }

  const handleDrop = (e) => {
    e.preventDefault()
    if (draggedAction) {
      // Handle repositioning logic here if needed
      setDraggedAction(null)
    }
  }

  if (actions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
        <p>Add actions to visualize your pipeline flow</p>
        <div className="mt-4 flex gap-2 flex-wrap justify-center">
          {actionTypes.map((type) => (
            <Button key={type.id} variant="outline" size="sm" onClick={() => onActionAdd(type)}>
              <div className={`w-3 h-3 ${type.shape} ${type.color} mr-2`}></div>
              <Plus className="mr-1 h-3 w-3" />
              {type.name}
            </Button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full h-[500px] overflow-auto"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-0" />
      <div className="relative z-10 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {actions.map((action, index) => (
            <div
              key={action.id}
              id={`visual-action-${action.id}`}
              className="action-node group relative"
              draggable
              onDragStart={(e) => handleDragStart(e, action)}
            >
              <div className="flex flex-col items-center p-4 bg-background rounded-lg shadow-lg border-2 border-border hover:border-primary transition-colors cursor-move">
                <div className={`p-4 ${action.shape} ${action.color} mb-3 relative`}>
                  <LucideIcon name={action.icon} className="h-8 w-8 text-white" />
                  <div className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                    <Button
                      variant="secondary"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation()
                        onActionEdit(action)
                      }}
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation()
                        onActionRemove(action.id)
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <h3 className="font-medium text-center text-sm">{action.name}</h3>
                <p className="text-xs font-semibold mt-1 px-2 py-1 rounded-full bg-muted">{action.action}</p>
                {action.dependencies && action.dependencies.length > 0 && (
                  <div className="mt-2 text-xs text-muted-foreground">Deps: {action.dependencies.length}</div>
                )}
                <div className="mt-2 text-xs text-muted-foreground">
                  {Object.keys(action.properties).length} properties
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-2 flex-wrap justify-center">
          <p className="text-sm text-muted-foreground mr-4">Add more actions:</p>
          {actionTypes.map((type) => (
            <Button key={type.id} variant="outline" size="sm" onClick={() => onActionAdd(type)}>
              <div className={`w-3 h-3 ${type.shape} ${type.color} mr-2`}></div>
              <Plus className="mr-1 h-3 w-3" />
              {type.name}
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}
