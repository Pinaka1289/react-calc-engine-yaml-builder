"use client"

import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { GripVertical, Pencil, Trash2 } from "lucide-react"
import { LucideIcon } from "@/lib/icons"

export function SortableAction({ action, onEdit, onRemove }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: action.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <Card ref={setNodeRef} style={style} className="relative">
      <div className={`absolute top-0 left-0 w-2 h-full ${action.color} rounded-l-md`} />
      <CardContent className="p-4 pl-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing">
            <GripVertical className="h-5 w-5 text-muted-foreground" />
          </div>

          <div className="flex items-center gap-2">
            <div className={`p-2 ${action.shape} ${action.color} bg-opacity-20`}>
              <LucideIcon name={action.icon} className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">{action.name}</h3>
              <p className="text-sm text-muted-foreground">
                <span className="font-medium">Action:</span> {action.action}
                {action.properties.dataframe && (
                  <span className="ml-2">
                    <span className="font-medium">DF:</span> {action.properties.dataframe}
                  </span>
                )}
                {action.dependencies && action.dependencies.length > 0 && (
                  <span className="ml-2">• Dependencies: {action.dependencies.length}</span>
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
            <span className="sr-only">Edit</span>
          </Button>
          <Button variant="ghost" size="icon" onClick={onRemove}>
            <Trash2 className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
