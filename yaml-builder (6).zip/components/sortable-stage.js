"use client"

import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { GripVertical, Pencil, Trash2 } from "lucide-react"
import { LucideIcon } from "@/lib/icons"

export function SortableStage({ stage, onEdit, onRemove }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: stage.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  return (
    <Card ref={setNodeRef} style={style} className="relative">
      <div className={`absolute top-0 left-0 w-2 h-full ${stage.color} rounded-l-md`} />
      <CardContent className="p-4 pl-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing">
            <GripVertical className="h-5 w-5 text-muted-foreground" />
          </div>

          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-md ${stage.color} bg-opacity-20`}>
              <LucideIcon name={stage.icon} className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">{stage.name}</h3>
              <p className="text-sm text-muted-foreground">
                {stage.dependencies && stage.dependencies.length > 0
                  ? `Dependencies: ${stage.dependencies.length}`
                  : "No dependencies"}
              </p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
            <span className="sr-only">Edit</span>
          </Button>
          <Button variant="ghost" size="icon" onClick={onRemove}>
            <Trash2 className="h-4 w-4" />
            <span className="sr-only">Remove</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
