"use client"

import { useEffect, useRef } from "react"
import { LucideIcon } from "@/lib/icons"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Pencil, Trash2, Plus } from "lucide-react"
import { actionTypes } from "@/lib/action-schemas"

export function FlowVisualizer({ actions, connections, onActionEdit, onActionRemove, onActionAdd }) {
  const canvasRef = useRef(null)
  const containerRef = useRef(null)

  // Ensure actions is an array
  const safeActions = Array.isArray(actions) ? actions : []

  // Calculate statistics
  const totalActions = safeActions.length
  const actionStats = actionTypes.reduce((stats, type) => {
    stats[type.id] = safeActions.filter((action) => action.action === type.id).length
    return stats
  }, {})

  // Organize actions in workflow layout
  const organizeWorkflow = () => {
    if (safeActions.length === 0) return { levels: [], startNodes: [], endNodes: [] }

    const levels = []
    const visited = new Set()
    const startNodes = safeActions.filter((action) => !action.dependencies || action.dependencies.length === 0)
    const endNodes = safeActions.filter((action) => !connections.some((conn) => conn.from === action.id))

    // Level 0: Start nodes (no dependencies)
    if (startNodes.length > 0) {
      levels.push(startNodes)
      startNodes.forEach((node) => visited.add(node.id))
    }

    // Build subsequent levels
    let currentLevel = 0
    while (visited.size < safeActions.length && currentLevel < 10) {
      // Prevent infinite loops
      const nextLevel = []

      safeActions.forEach((action) => {
        if (!visited.has(action.id)) {
          // Check if all dependencies are in previous levels
          const allDepsVisited = !action.dependencies || action.dependencies.every((depId) => visited.has(depId))
          if (allDepsVisited) {
            nextLevel.push(action)
          }
        }
      })

      if (nextLevel.length === 0) {
        // Add remaining unvisited nodes
        const remaining = safeActions.filter((action) => !visited.has(action.id))
        if (remaining.length > 0) {
          levels.push(remaining)
          remaining.forEach((node) => visited.add(node.id))
        }
        break
      }

      levels.push(nextLevel)
      nextLevel.forEach((node) => visited.add(node.id))
      currentLevel++
    }

    return { levels, startNodes, endNodes }
  }

  const { levels, startNodes, endNodes } = organizeWorkflow()

  useEffect(() => {
    if (!canvasRef.current || safeActions.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas dimensions
    const container = canvas.parentElement
    canvas.width = container.offsetWidth
    canvas.height = container.offsetHeight

    // Draw connections
    ctx.strokeStyle = "#3b82f6"
    ctx.lineWidth = 2

    connections.forEach((connection) => {
      const fromElement = document.getElementById(`flow-action-${connection.from}`)
      const toElement = document.getElementById(`flow-action-${connection.to}`)

      if (fromElement && toElement) {
        const fromRect = fromElement.getBoundingClientRect()
        const toRect = toElement.getBoundingClientRect()
        const canvasRect = canvas.getBoundingClientRect()

        const fromX = fromRect.left + fromRect.width / 2 - canvasRect.left
        const fromY = fromRect.bottom - canvasRect.top
        const toX = toRect.left + toRect.width / 2 - canvasRect.left
        const toY = toRect.top - canvasRect.top

        // Draw arrow
        ctx.beginPath()
        ctx.moveTo(fromX, fromY)

        // Create curved line for better visibility
        const midY = (fromY + toY) / 2
        ctx.quadraticCurveTo(fromX, midY, toX, toY)
        ctx.stroke()

        // Draw arrow head
        const angle = Math.atan2(toY - midY, toX - fromX)
        const arrowSize = 8

        ctx.beginPath()
        ctx.moveTo(toX, toY)
        ctx.lineTo(toX - arrowSize * Math.cos(angle - Math.PI / 6), toY - arrowSize * Math.sin(angle - Math.PI / 6))
        ctx.lineTo(toX - arrowSize * Math.cos(angle + Math.PI / 6), toY - arrowSize * Math.sin(angle + Math.PI / 6))
        ctx.closePath()
        ctx.fillStyle = "#3b82f6"
        ctx.fill()
      }
    })
  }, [safeActions, connections])

  if (safeActions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
        <p>Add actions to visualize your pipeline flow</p>
        <div className="mt-4 flex gap-2 flex-wrap justify-center">
          {actionTypes.map((type) => (
            <Button key={type.id} variant="outline" size="sm" onClick={() => onActionAdd(type)}>
              <div className={`w-3 h-3 ${type.shape} ${type.color} mr-2`}></div>
              <Plus className="mr-1 h-3 w-3" />
              {type.name}
            </Button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative w-full h-[600px] overflow-auto">
      {/* Statistics Panel */}
      <Card className="absolute top-4 right-4 z-20 bg-background/95 backdrop-blur">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2">Pipeline Statistics</h3>
          <div className="space-y-1 text-sm">
            <div className="font-medium">Total Actions: {totalActions}</div>
            {actionTypes.map((type) => (
              <div key={type.id} className="flex items-center gap-2">
                <div className={`w-3 h-3 ${type.shape} ${type.color}`}></div>
                <span>
                  {type.name}: {actionStats[type.id]}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-0" />

      <div className="relative z-10 p-8">
        {/* Workflow Levels */}
        <div className="space-y-16">
          {levels.map((level, levelIndex) => (
            <div key={levelIndex} className="flex justify-center">
              <div className="flex gap-8 flex-wrap justify-center">
                {level.map((action) => {
                  const actionType = actionTypes.find((type) => type.id === action.action)
                  const isStart = startNodes.includes(action)
                  const isEnd = endNodes.includes(action)

                  return (
                    <div
                      key={action.id}
                      id={`flow-action-${action.id}`}
                      className="group relative flex flex-col items-center"
                    >
                      {/* Start/End indicators */}
                      {isStart && (
                        <div className="absolute -top-6 text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded">
                          START
                        </div>
                      )}
                      {isEnd && (
                        <div className="absolute -bottom-6 text-xs font-semibold text-red-600 bg-red-100 px-2 py-1 rounded">
                          END
                        </div>
                      )}

                      {/* Action Node */}
                      <div className="flex flex-col items-center p-3 bg-background rounded-lg shadow-lg border-2 border-border hover:border-primary transition-all cursor-pointer group-hover:scale-105">
                        <div className={`p-3 ${action.shape} ${action.color} mb-2 relative`}>
                          <LucideIcon name={action.icon} className="h-6 w-6 text-white" />

                          {/* Action controls */}
                          <div className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                            <Button
                              variant="secondary"
                              size="icon"
                              className="h-5 w-5"
                              onClick={(e) => {
                                e.stopPropagation()
                                onActionEdit(action)
                              }}
                            >
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="icon"
                              className="h-5 w-5"
                              onClick={(e) => {
                                e.stopPropagation()
                                onActionRemove(action.id)
                              }}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        <div className="text-center">
                          <div className="text-xs font-semibold text-primary mb-1">{action.action.toUpperCase()}</div>
                          <div className="text-sm font-medium">{action.name}</div>
                          {action.properties && action.properties.dataframe && (
                            <div className="text-xs text-muted-foreground mt-1">DF: {action.properties.dataframe}</div>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Add Actions */}
        <div className="mt-12 flex gap-2 flex-wrap justify-center">
          <p className="text-sm text-muted-foreground mr-4 self-center">Add more actions:</p>
          {actionTypes.map((type) => (
            <Button key={type.id} variant="outline" size="sm" onClick={() => onActionAdd(type)}>
              <div className={`w-3 h-3 ${type.shape} ${type.color} mr-2`}></div>
              <Plus className="mr-1 h-3 w-3" />
              {type.name}
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}
