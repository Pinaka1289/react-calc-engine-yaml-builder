"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LucideIcon } from "@/lib/icons"
import { getActionSchema } from "@/lib/action-schemas"
import { Trash2, Plus } from "lucide-react"

export function ActionEditor({ action, allActions, onSave, onCancel }) {
  const [editedAction, setEditedAction] = useState({ ...action })
  const [rawActionText, setRawActionText] = useState("")
  const [newPropertyKey, setNewPropertyKey] = useState("")
  const [newPropertyValue, setNewPropertyValue] = useState("")
  const schema = getActionSchema(action.action)

  const handleNameChange = (e) => {
    setEditedAction({ ...editedAction, name: e.target.value })
  }

  const updateProperty = (key, value) => {
    setEditedAction({
      ...editedAction,
      properties: {
        ...editedAction.properties,
        [key]: value,
      },
    })
  }

  const removeProperty = (key) => {
    const updatedProperties = { ...editedAction.properties }
    delete updatedProperties[key]
    setEditedAction({
      ...editedAction,
      properties: updatedProperties,
    })
  }

  const addOptionalProperty = (key) => {
    if (key && !editedAction.properties.hasOwnProperty(key)) {
      setEditedAction({
        ...editedAction,
        properties: {
          ...editedAction.properties,
          [key]: "",
        },
      })
    }
  }

  const addCustomProperty = () => {
    if (newPropertyKey.trim() && !editedAction.properties.hasOwnProperty(newPropertyKey)) {
      setEditedAction({
        ...editedAction,
        properties: {
          ...editedAction.properties,
          [newPropertyKey]: newPropertyValue,
        },
      })
      setNewPropertyKey("")
      setNewPropertyValue("")
    }
  }

  const parseRawAction = () => {
    try {
      const lines = rawActionText.split("\n").filter((line) => line.trim())
      const actionData = {}

      lines.forEach((line) => {
        const colonIndex = line.indexOf(":")
        if (colonIndex > 0) {
          const key = line.substring(0, colonIndex).trim()
          const value = line.substring(colonIndex + 1).trim()
          actionData[key] = value
        }
      })

      if (actionData.name) {
        setEditedAction({
          ...editedAction,
          name: actionData.name,
          properties: {
            ...Object.fromEntries(Object.entries(actionData).filter(([key]) => key !== "action" && key !== "name")),
          },
        })
      }
    } catch (error) {
      alert("Error parsing raw action: " + error.message)
    }
  }

  const availableOptionalProps = schema.optional.filter((prop) => !editedAction.properties.hasOwnProperty(prop))

  const validateAction = () => {
    const missingMandatory = schema.mandatory.filter((prop) => {
      if (prop === "action" || prop === "name") return false
      return !editedAction.properties[prop] || editedAction.properties[prop].trim() === ""
    })

    if (missingMandatory.length > 0) {
      return `Missing mandatory properties: ${missingMandatory.join(", ")}`
    }

    if (!editedAction.name.trim()) {
      return "Action name is required"
    }

    return null
  }

  const handleSave = () => {
    const error = validateAction()
    if (error) {
      alert(error)
      return
    }
    onSave(editedAction)
  }

  return (
    <Dialog open={true} onOpenChange={() => onCancel()}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Action</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic">
          <TabsList className="mb-4">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="properties">Properties</TabsTrigger>
            <TabsTrigger value="raw">Raw Input</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <div className="flex items-center gap-4 mb-4">
              <div className={`p-3 ${editedAction.shape} ${editedAction.color}`}>
                <LucideIcon name={editedAction.icon} className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-medium">
                  {editedAction.action.charAt(0).toUpperCase() + editedAction.action.slice(1)} Action
                </p>
                <p className="text-sm text-muted-foreground">Configure the basic settings</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  Action Name <span className="text-red-500">*</span>
                </Label>
                <Input id="name" value={editedAction.name} onChange={handleNameChange} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="properties" className="space-y-4">
            <div className="space-y-6">
              {/* Mandatory Properties */}
              <div>
                <h3 className="text-sm font-medium mb-3 text-red-600">
                  Mandatory Properties <span className="text-red-500">*</span>
                </h3>
                <div className="space-y-3">
                  {schema.mandatory
                    .filter((prop) => prop !== "action" && prop !== "name")
                    .map((prop) => (
                      <div key={prop} className="space-y-1">
                        <Label htmlFor={prop}>
                          {prop} <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id={prop}
                          value={editedAction.properties[prop] || ""}
                          onChange={(e) => updateProperty(prop, e.target.value)}
                          placeholder={`Enter ${prop}`}
                        />
                      </div>
                    ))}
                </div>
              </div>

              {/* Optional Properties */}
              <div>
                <h3 className="text-sm font-medium mb-3 text-blue-600">Optional Properties</h3>
                <div className="space-y-3">
                  {schema.optional
                    .filter((prop) => editedAction.properties.hasOwnProperty(prop))
                    .map((prop) => (
                      <div key={prop} className="flex items-center gap-2">
                        <div className="flex-1 space-y-1">
                          <Label htmlFor={prop}>{prop}</Label>
                          <Input
                            id={prop}
                            value={editedAction.properties[prop]}
                            onChange={(e) => updateProperty(prop, e.target.value)}
                            placeholder={`Enter ${prop}`}
                          />
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => removeProperty(prop)} className="mt-6">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}

                  {availableOptionalProps.length > 0 && (
                    <div className="pt-2">
                      <Select onValueChange={addOptionalProperty}>
                        <SelectTrigger>
                          <SelectValue placeholder="Add optional property" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableOptionalProps.map((prop) => (
                            <SelectItem key={prop} value={prop}>
                              {prop}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>

              {/* Custom Properties */}
              <div>
                <h3 className="text-sm font-medium mb-3 text-green-600">Custom Properties</h3>
                <div className="space-y-3">
                  {Object.entries(editedAction.properties)
                    .filter(([key]) => !schema.mandatory.includes(key) && !schema.optional.includes(key))
                    .map(([key, value]) => (
                      <div key={key} className="flex items-center gap-2">
                        <div className="flex-1 space-y-1">
                          <Label>{key}</Label>
                          <Input
                            value={value}
                            onChange={(e) => updateProperty(key, e.target.value)}
                            placeholder={`Enter ${key}`}
                          />
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => removeProperty(key)} className="mt-6">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}

                  <div className="flex gap-2">
                    <Input
                      placeholder="Property name"
                      value={newPropertyKey}
                      onChange={(e) => setNewPropertyKey(e.target.value)}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Property value"
                      value={newPropertyValue}
                      onChange={(e) => setNewPropertyValue(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={addCustomProperty}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="raw" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="rawAction">Paste Raw Action (key: value format)</Label>
                <Textarea
                  id="rawAction"
                  value={rawActionText}
                  onChange={(e) => setRawActionText(e.target.value)}
                  placeholder={`Example:
name: My Custom Action
dataframe: my_data
location: /path/to/data
tableName: users`}
                  className="min-h-[200px] font-mono"
                />
              </div>
              <Button onClick={parseRawAction}>Parse and Apply</Button>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
